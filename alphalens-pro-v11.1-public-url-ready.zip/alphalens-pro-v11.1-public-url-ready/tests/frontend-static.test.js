import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');const js=fs.readFileSync(new URL('../app.js',import.meta.url),'utf8');
test('all referenced IDs exist',()=>{const ids=new Set([...html.matchAll(/id="([^"]+)"/g)].map(x=>x[1]));const refs=new Set([...js.matchAll(/\$\('#([A-Za-z0-9_-]+)'\)/g)].map(x=>x[1]));assert.deepEqual([...refs].filter(x=>!ids.has(x)),[])});
test('critical handlers exist',()=>{for(const id of ['refreshFundamentals','refreshAiJudgement','translateCompanyProfile','refreshQuote','refreshCompanyProfile','searchBtn'])assert.match(js,new RegExp(`\\$\\('#${id}'\\)\\.onclick`))});
test('cache bust and backend status exist',()=>{assert.match(html,/app\.js\?v=11\.0\.0/);assert.match(html,/id="backendStatus"/)});
test('fundamental and AI panels exist',()=>{for(const id of ['fundDonut','subScores','metrics','aiJudgement'])assert.match(html,new RegExp(`id="${id}"`))});
